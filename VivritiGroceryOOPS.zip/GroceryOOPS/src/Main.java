import java.util.ArrayList;
import java.util.List;

import com.grocery.transaction.module.controller.TransactionController;
import com.grocery.transaction.module.model.request.ItemRequest;
import com.grocery.transaction.module.model.response.ResultResponse;

public class Main {
	
	
	public static void main(String[] args) {
		System.out.println("Hello");
		
		TransactionController controller = new TransactionController();
		
		List<ItemRequest> itemRequestList = new ArrayList<>();
		
		ItemRequest request = new ItemRequest();
		request.setId(1l);
		request.setQuantity(1l);
		itemRequestList.add(request);

		try {
			ResultResponse response  = controller.buyItem(itemRequestList);
			System.out.println(response.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
