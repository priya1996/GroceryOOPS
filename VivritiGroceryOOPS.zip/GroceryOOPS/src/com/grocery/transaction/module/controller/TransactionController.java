package com.grocery.transaction.module.controller;

import java.util.List;

import com.grocery.transaction.module.model.request.InventoryRequest;
import com.grocery.transaction.module.model.request.ItemRequest;
import com.grocery.transaction.module.model.request.SalesRequest;
import com.grocery.transaction.module.model.response.InventoryResponse;
import com.grocery.transaction.module.model.response.ResultResponse;
import com.grocery.transaction.module.service.impl.TransactionServiceImpl;


public class TransactionController {

	TransactionServiceImpl transactionService = new TransactionServiceImpl();

	
	public ResultResponse buyItem(
			 List<ItemRequest> itemRequestList)
			throws Exception {
		return transactionService.buyItem(itemRequestList);
	}

	
	public List<InventoryResponse> printInventory(InventoryRequest request)
			throws Exception {
		return transactionService.printInventory(request);
	}

	public ResultResponse getTotalSales(SalesRequest request)
			throws Exception {
		return transactionService.getTotalSales(request);
	}

	
	public ResultResponse applyDiscountForEmployee(Long empId,List<ItemRequest> itemRequestList)
			throws Exception {
		return transactionService.applyDiscountForEmployee(empId, itemRequestList);
	}

	
	public ResultResponse applyDiscountForCustomer(List<ItemRequest> itemRequestList)
			throws Exception {
		return transactionService.applyDiscountForCustomer(itemRequestList);
	}

	
}
