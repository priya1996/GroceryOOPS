package com.grocery.transaction.module.model.bo;

import java.util.Date;





public class DailyPurchase {

	private Long id;

	private Long quantityLeft;

	private Date date;

	private Long itemId;

	private Double salesCost;

	private Date createdOn;

	private Date modifiedOn;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public Long getQuantityLeft() {
		return quantityLeft;
	}

	public void setQuantityLeft(Long quantityLeft) {
		this.quantityLeft = quantityLeft;
	}


	public Double getSalesCost() {
		return salesCost;
	}

	public void setSalesCost(Double salesCost) {
		this.salesCost = salesCost;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
