package com.grocery.transaction.module.model.bo;

import java.util.Date;





public class Transaction {

	private Long id;

	private Double totalCost;

	private String customerPaymentType;

	private Long counterId;

	private Date createdOn;

	private Date modifiedOn;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCounterId() {
		return counterId;
	}

	public void setCounterId(Long counterId) {
		this.counterId = counterId;
	}

	public Double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

	public String getCustomerPaymentType() {
		return customerPaymentType;
	}

	public void setCustomerPaymentType(String customerPaymentType) {
		this.customerPaymentType = customerPaymentType;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}


}
