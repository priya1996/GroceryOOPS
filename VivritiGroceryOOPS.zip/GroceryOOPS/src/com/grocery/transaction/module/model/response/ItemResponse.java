package com.grocery.transaction.module.model.response;

import java.util.Date;

public class ItemResponse {
	
	private Long itemId;
	
	private String itemName;
	
	private Long quantityLeft;
	
	private Date date;
	
	private Long quantitySold;
	
	private Double cost;

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Long getQuantityLeft() {
		return quantityLeft;
	}

	public void setQuantityLeft(Long quantityLeft) {
		this.quantityLeft = quantityLeft;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Long getQuantitySold() {
		return quantitySold;
	}

	public void setQuantitySold(Long quantitySold) {
		this.quantitySold = quantitySold;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}
	
	

}
