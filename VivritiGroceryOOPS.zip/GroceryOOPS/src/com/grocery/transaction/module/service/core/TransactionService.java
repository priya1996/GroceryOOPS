package com.grocery.transaction.module.service.core;

import java.util.List;

import com.grocery.transaction.module.model.request.InventoryRequest;
import com.grocery.transaction.module.model.request.ItemRequest;
import com.grocery.transaction.module.model.request.SalesRequest;
import com.grocery.transaction.module.model.response.InventoryResponse;
import com.grocery.transaction.module.model.response.ResultResponse;
import com.grocery.transaction.module.model.response.ItemResponse;



public interface TransactionService {

	public ResultResponse buyItem(List<ItemRequest> itemRequestList);
			
	public List<InventoryResponse> printInventory(InventoryRequest request);

	public ResultResponse getTotalSales(SalesRequest request);
	
	public ResultResponse applyDiscountForEmployee(Long empId,List<ItemRequest> itemRequestList);		

	public ResultResponse applyDiscountForCustomer(List<ItemRequest> itemRequestList);
	
}
