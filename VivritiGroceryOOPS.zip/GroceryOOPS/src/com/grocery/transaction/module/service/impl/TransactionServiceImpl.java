package com.grocery.transaction.module.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.grocery.transaction.module.model.bo.DailyPurchase;
import com.grocery.transaction.module.model.bo.Discount;
import com.grocery.transaction.module.model.bo.DiscountItemEmployeeMapping;
import com.grocery.transaction.module.model.bo.Item;
import com.grocery.transaction.module.model.bo.Transaction;
import com.grocery.transaction.module.model.bo.TransactionItem;
import com.grocery.transaction.module.model.request.InventoryRequest;
import com.grocery.transaction.module.model.request.ItemRequest;
import com.grocery.transaction.module.model.request.SalesRequest;
import com.grocery.transaction.module.model.response.InventoryResponse;
import com.grocery.transaction.module.model.response.ItemResponse;
import com.grocery.transaction.module.model.response.ResultResponse;
import com.grocery.transaction.module.service.core.TransactionService;


public class TransactionServiceImpl implements TransactionService {


	
	@Override
	public ResultResponse buyItem(List<ItemRequest> itemRequestList)
	{
		// Null and Empty check for Request Object List
		if(itemRequestList.isEmpty() || itemRequestList == null) {
			ResultResponse response = new ResultResponse();
			response.setMsg("BadRequest");
			response.setCode("Error");
			return response;
		}
		
		List<ItemResponse> itemResponseList = new ArrayList<>();
		
		List<Item> items = getItems();
		
		Transaction transaction = new Transaction();
		transaction.setCreatedOn(new Date());
		transaction.setModifiedOn(new Date());
		
		Double totalCost = 0D;
		
		for(ItemRequest request : itemRequestList) {
			
			List<Item> itemList = items.stream().filter(x->x.getId().equals(request.getId())).map(x->x).collect(Collectors.toList());
			if(!itemList.isEmpty() && itemList != null) {
				
				Item item = itemList.get(0);
				List<DailyPurchase> dpList = getDailyPurchaseByItemId(request.getId());

				if(item.getExpiryDate().after(new Date()) && ((dpList.isEmpty() && request.getQuantity() < item.getQuantity()) || (dpList == null && request.getQuantity() < item.getQuantity()) || dpList.get(0).getQuantityLeft()>request.getQuantity())) {
					
						totalCost += request.getQuantity()*item.getPrice();
						
						ItemResponse itemResponse = new ItemResponse();
						itemResponse.setCost(request.getQuantity()*item.getPrice());
						itemResponse.setItemId(item.getId());
						itemResponse.setItemName(item.getName());
						itemResponse.setQuantitySold(request.getQuantity());
						
						itemResponseList.add(itemResponse);
					
				}
				
			}
		}
		
		
		ResultResponse resultResponse = new ResultResponse();
		resultResponse.setBillId(transaction.getId());
		resultResponse.setTotalBillCost(totalCost);
		resultResponse.setItemResponseList(itemResponseList);
		resultResponse.setCode("200");
		resultResponse.setMsg("success");
		
		return resultResponse;
	}

	@Override
	public List<InventoryResponse> printInventory(InventoryRequest request)
	{
		List<Item> itemList = null;
		List<InventoryResponse> inventoryResponseList = new ArrayList<>();
			itemList = getItems();
		
		for(Item item : itemList) {
			
			InventoryResponse ir = new InventoryResponse();
			ir.setDate(new Date());
			ir.setItemId(item.getId());
			ir.setItemName(item.getName());
			
			List<DailyPurchase> dpList = getDailyPurchaseByItemId(item.getId());

			ir.setQuantityLeft(dpList.get(0).getQuantityLeft());
			ir.setQuantitySold(item.getQuantity() - dpList.get(0).getQuantityLeft());
			
			inventoryResponseList.add(ir);
			
		}
		
		return inventoryResponseList;
	}

	@Override
	public ResultResponse getTotalSales(SalesRequest request)
	{
		ResultResponse response = new ResultResponse();
		List<ItemResponse> itemResponseList = new ArrayList<>();
		List<Item> itemList = getItems();
		
		
		for(Item item : itemList) {
			
			ItemResponse itemResponse = new ItemResponse();
			itemResponse.setItemId(item.getId());
			itemResponse.setItemName(item.getName());
			itemResponse.setDate(request.getDate());
			List<DailyPurchase> dpList = getDailyPurchaseByItemId(item.getId());

			itemResponse.setQuantityLeft(dpList.get(0).getQuantityLeft());
			itemResponse.setQuantitySold(item.getQuantity() - dpList.get(0).getQuantityLeft());
			
			itemResponseList.add(itemResponse);
		}
		response.setItemResponseList(itemResponseList);
		
		return response;
	}

	@Override
	public ResultResponse applyDiscountForEmployee(Long empId, List<ItemRequest> itemRequestList)
	{
		List<DiscountItemEmployeeMapping> discountList = getDiscountItemEmployeeMappingByEmpId(empId);
		
		Double totalCost = 0D;
		
		List<ItemResponse> itemResponseList = new ArrayList<>();
		
		for(ItemRequest request : itemRequestList) {
			
			List<DiscountItemEmployeeMapping> dis = discountList.stream().filter(x->x.getItemId().equals(
					request.getId())).map(x->x).collect(Collectors.toList());
			
			if(dis != null && !dis.isEmpty()) {
				
				List<Item> itemList = getItems();
					
				Item item = itemList.get(0);
				List<DailyPurchase> dpList = getDailyPurchaseByItemId(request.getId());

				Discount discount = getDiscountById(dis.get(0).getId());

				Double cost = item.getPrice() - (item.getPrice() * discount.getPercent()/100);
								
				totalCost += request.getQuantity()*cost;
				
				ItemResponse itemResponse = new ItemResponse();
				itemResponse.setCost(request.getQuantity()*cost);
				itemResponse.setItemId(item.getId());
				itemResponse.setItemName(item.getName());
				itemResponse.setQuantitySold(request.getQuantity());
				
				itemResponseList.add(itemResponse);
			}
			
		}
		
		ResultResponse resultResponse = new ResultResponse();
		resultResponse.setTotalBillCost(totalCost);
		resultResponse.setItemResponseList(itemResponseList);
		resultResponse.setCode("200");
		resultResponse.setMsg("success");
		
		return resultResponse;
		
	}

	@Override
	public ResultResponse applyDiscountForCustomer(List<ItemRequest> itemRequestList)
	{
				
		List<Item> items = getItems();
		
		Double totalCost = 0D;
		
		List<ItemResponse> itemResponseList = new ArrayList<>();
		
		for(ItemRequest request : itemRequestList) {
			
			List<DiscountItemEmployeeMapping> dis = getDiscountItemEmployeeMappingByItemId(request.getId());

			if(dis != null && !dis.isEmpty()) {
				
				List<Item> itemList = items.stream().filter(x->x.getId().equals(request.getId())).map(x->x).collect(Collectors.toList());
					
				Item item = itemList.get(0);
				List<DailyPurchase> dpList = getDailyPurchaseByItemId(request.getId());

				Discount discount = getDiscountById(dis.get(0).getId());
				
				Double cost = item.getPrice() - (item.getPrice() * discount.getPercent()/100);
								
				totalCost += request.getQuantity()*cost;
				
				ItemResponse itemResponse = new ItemResponse();
				itemResponse.setCost(request.getQuantity()*cost);
				itemResponse.setItemId(item.getId());
				itemResponse.setItemName(item.getName());
				itemResponse.setQuantitySold(request.getQuantity());
				
				itemResponseList.add(itemResponse);
			}
			
		}
		
		
		ResultResponse resultResponse = new ResultResponse();
		resultResponse.setTotalBillCost(totalCost);
		resultResponse.setItemResponseList(itemResponseList);
		resultResponse.setCode("200");
		resultResponse.setMsg("success");
		
		return resultResponse;
	}
	
	public List<Item> getItems(){
		
		List<Item> items = new ArrayList<>();
		for(int i=0 ; i<10 ; i++) {
			
			Item item = new Item();
			item.setId((long)i+1);
			item.setName("Item" + item.getId().toString());
			item.setPrice(item.getId() * 100.0000);
			item.setQuantity(item.getId() * 10);
			item.setCreatedOn(new Date());
			item.setModifiedOn(new Date());
			item.setLoadInDate(new Date());
			item.setExpiryDate(new Date());

			items.add(item);
		}
		
		return items;
	}
	
	public List<DailyPurchase> getDailyPurchaseByItemId(Long itemId){
		
		List<DailyPurchase> dailyPurchases = new ArrayList<>();
		for(int i=0 ; i<10 ; i++) {
			
			DailyPurchase dailyPurchase = new DailyPurchase();
			dailyPurchase.setId((long)i+1);
			dailyPurchase.setSalesCost(100.0000);
			dailyPurchase.setQuantityLeft((long)i+1 * 5);
			dailyPurchase.setCreatedOn(new Date());
			dailyPurchase.setModifiedOn(new Date());
			dailyPurchase.setDate(new Date());
			dailyPurchase.setItemId((long)i+1);

			dailyPurchases.add(dailyPurchase);
		}
		
		List<DailyPurchase> dpList = dailyPurchases.stream().filter(x->x.getItemId().equals(itemId)).map(x->x).collect(Collectors.toList());
		
		return dpList;
		
	}
	
	public List<DiscountItemEmployeeMapping> getDiscountItemEmployeeMappingByItemId(Long itemId){
		
		List<DiscountItemEmployeeMapping> list = new ArrayList<>();
		
		DiscountItemEmployeeMapping obj = new DiscountItemEmployeeMapping();
		obj.setCreatedOn(new Date());
		obj.setModifiedOn(new Date());
		obj.setDiscountId(1l);
		obj.setItemId(1l);
		obj.setId(1l);
		
		list.add(obj);
		
		return list;
	}
	
	public List<DiscountItemEmployeeMapping> getDiscountItemEmployeeMappingByEmpId(Long empId){
		
		List<DiscountItemEmployeeMapping> list = new ArrayList<>();
		
		DiscountItemEmployeeMapping obj = new DiscountItemEmployeeMapping();
		obj.setCreatedOn(new Date());
		obj.setModifiedOn(new Date());
		obj.setDiscountId(1l);
		obj.setEmployeeId(1l);
		obj.setId(1l);
		
		list.add(obj);
		
		return list;
	}
	
	public Discount getDiscountById(Long id) {
		
		Discount discount = new Discount();
		discount.setId(1l);
		discount.setPercent(10d);
		
		return discount;
	}
}
